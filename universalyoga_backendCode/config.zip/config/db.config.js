module.exports = {
    url:"mongodb+srv://universalyoga:Wi6ZQLaG2HtAFqdL@cluster0.q4tu0ub.mongodb.net/universalyoga"
}
