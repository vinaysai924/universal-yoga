module.exports = {
    secret: "universal-yoga-secret-key"
};